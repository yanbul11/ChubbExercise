﻿using Exercise.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Exercise.Data
{
    public class ChainDbContext : DbContext
    {
        public ChainDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Restaurant> Restaurants { get; set; }

        public DbSet<Product> Products { get; set; }

        public DbSet<Material> Materials { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<OrderItem> OrderItems { get; set; }

        public DbSet<Supply> Supplies { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasIndex(o => o.Name)
                .IsUnique();

            modelBuilder.Entity<Material>()
                .HasIndex(o => o.Name)
                .IsUnique();

            modelBuilder.Entity<Restaurant>().HasData(SeedData.Restaurants);
            modelBuilder.Entity<Product>().HasData(SeedData.Products);
            modelBuilder.Entity<Material>().HasData(SeedData.Materials);

            modelBuilder.Entity<Order>().HasData(SeedData.Orders);
            modelBuilder.Entity<OrderItem>().HasData(SeedData.OrderItems);
            modelBuilder.Entity<Supply>().HasData(SeedData.Supplies);
        }
    }
}
