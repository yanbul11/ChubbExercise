﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Exercise.Data
{
    internal class ChainDbContextFactory : IDesignTimeDbContextFactory<ChainDbContext>
    {
        private const string DesignTimeDataSource = "Chain.db";

        public ChainDbContext CreateDbContext(string[] args)
        {
            var options = new DbContextOptionsBuilder<ChainDbContext>()
                .UseSqlite($"Data Source={DesignTimeDataSource}")
                .Options;

            return new ChainDbContext(options);
        }
    }
}
