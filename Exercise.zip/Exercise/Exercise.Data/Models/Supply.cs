﻿using System.ComponentModel.DataAnnotations;

namespace Exercise.Data.Models
{
    public class Supply
    {
        [Key]
        public int SupplyId { get; set; }

        [Required]
        public int RestaurantId { get; set; }

        public Restaurant Restaurant { get; set; }

        [Required]
        public int MaterialId { get; set; }

        public Material Material { get; set; }

        public int Quantity { get; set; }
    }
}
