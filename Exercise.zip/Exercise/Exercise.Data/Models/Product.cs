﻿using System.ComponentModel.DataAnnotations;

namespace Exercise.Data.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [Required]
        public string Name { get; set; }
    }
}
