﻿using System.ComponentModel.DataAnnotations;

namespace Exercise.Data.Models
{
    public class Restaurant
    {
        [Key]
        public int RestaurantId { get; set; }
    }
}
