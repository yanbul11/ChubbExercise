﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exercise.Data.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public int RestaurantId { get; set; }

        public Restaurant Restaurant { get; set; }

        public ICollection<OrderItem> Items { get; set; }
    }
}
