﻿using System.ComponentModel.DataAnnotations;

namespace Exercise.Data.Models
{
    public class Material
    {
        [Key]
        public int MaterialId { get; set; }

        [Required]
        public string Name { get; set; }
    }
}
