﻿using Exercise.Services;
using Exercise.Services.Dto;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Exercise.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        private readonly IRestaurantService _restaurantService;

        public RestaurantController(IRestaurantService restaurantService)
        {
            _restaurantService = restaurantService;
        }

        // GET api/chain/supply/[restaurantId]/[materialId]
        [HttpGet("supply/{restaurantId}/{materialId}")]
        public ActionResult<SupplyDto> Supply(int restaurantId, int materialId)
        {
            return Ok(_restaurantService.GetSupply(restaurantId, materialId));
        }
    }
}
