﻿using Exercise.Services;
using Exercise.Services.Dto;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Exercise.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChainController : ControllerBase
    {
        private readonly IChainService _chainService;

        public ChainController(IChainService chainService)
        {
            _chainService = chainService;
        }

        // GET api/chain/demands/[productId]
        [HttpGet("demands/{productId}")]
        public ActionResult<IEnumerable<DemandDto>> Demands(int productId)
        {
            return Ok(_chainService.GetDemands(productId));
        }
    }
}
