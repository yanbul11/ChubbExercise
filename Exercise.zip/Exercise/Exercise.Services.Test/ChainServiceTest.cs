using Exercise.Data;
using Exercise.Services;
using Exercise.Services.Dto;
using Exercise.Services.Test;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace Tests
{
    public class Tests
    {
        private static DbContextOptions CreateDbContextOptions(string memoryDatabaseName)
        {
            return new DbContextOptionsBuilder<ChainDbContext>()
                .UseInMemoryDatabase(memoryDatabaseName)
                .Options;
        }

        private static void CreateMemoryDatabase(DbContextOptions options)
        {
            using (var context = new ChainDbContext(options))
            {
                context.Restaurants.AddRange(TestSeedData.Restaurants);
                context.Products.AddRange(TestSeedData.Products);
                context.Materials.AddRange(TestSeedData.Materials);
                context.Orders.AddRange(TestSeedData.Orders);
                context.OrderItems.AddRange(TestSeedData.OrderItems);
                context.Supplies.AddRange(TestSeedData.Supplies);
                context.SaveChanges();
            }
        }

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestDemand()
        {
            // Arrange

            var options = CreateDbContextOptions("TestDemand");

            CreateMemoryDatabase(options);

            // Act

            IEnumerable<DemandDto> demands;

            using (var context = new ChainDbContext(options))
            {
                var service = new ChainService(context);
                demands = service.GetDemands(1);
            }

            // Assert

            Assert.NotNull(demands);
            Assert.AreEqual(2, demands.Count());

            Assert.That(demands.Any(o => o.RestaurantId == 1 && o.Quantity == 11));
            Assert.That(demands.Any(o => o.RestaurantId == 2 && o.Quantity == 7));
        }

        [Test]
        [TestCase(1, 1, 1)]
        [TestCase(2, 2, 0)]
        [TestCase(3, 3, 9)]
        [TestCase(4, 4, 5)]
        public void TestSupply(int testCaseId, int restaurantId, int expectedQuantity)
        {
            // Arrange

            var options = CreateDbContextOptions($"TestSupply{testCaseId}");

            CreateMemoryDatabase(options);

            // Act

            SupplyDto supply;

            using (var context = new ChainDbContext(options))
            {
                var service = new RestaurantService(context);
                supply = service.GetSupply(restaurantId, 1);
            }

            // Assert
            Assert.NotNull(supply);
            Assert.AreEqual(expectedQuantity, supply.Quantity);
        }
    }
}