﻿using Exercise.Data.Models;

namespace Exercise.Services.Test
{
    internal sealed class TestSeedData
    {
        public static readonly Restaurant[] Restaurants = new Restaurant[]
        {
            new Restaurant() { RestaurantId = 1 },
            new Restaurant() { RestaurantId = 2 },
            new Restaurant() { RestaurantId = 3 },
            new Restaurant() { RestaurantId = 4 }
        };

        public static readonly Product[] Products = new Product[]
        {
            new Product() { ProductId = 1, Name = "Tiramisu" }
        };

        public static readonly Material[] Materials = new Material[]
        {
            new Material() { MaterialId = 1, Name = "Egg" }
        };

        public static readonly Order[] Orders = new Order[]
        {
            new Order() { OrderId = 1, RestaurantId = 1 },
            new Order() { OrderId = 2, RestaurantId = 1 },
            new Order() { OrderId = 3, RestaurantId = 1 },
            new Order() { OrderId = 4, RestaurantId = 2 },
            new Order() { OrderId = 5, RestaurantId = 2 },
            new Order() { OrderId = 6, RestaurantId = 3 }
        };

        public static readonly OrderItem[] OrderItems = new OrderItem[]
        {
            new OrderItem() { OrderItemId = 1, OrderId = 1, ProductId = 1, Quantity = 1 },
            new OrderItem() { OrderItemId = 2, OrderId = 1, ProductId = 1, Quantity = 2 },
            new OrderItem() { OrderItemId = 3, OrderId = 2, ProductId = 1, Quantity = 3 },
            new OrderItem() { OrderItemId = 4, OrderId = 3, ProductId = 1, Quantity = 2 },
            new OrderItem() { OrderItemId = 5, OrderId = 3, ProductId = 1, Quantity = 3 },
            new OrderItem() { OrderItemId = 6, OrderId = 4, ProductId = 1, Quantity = 1 },
            new OrderItem() { OrderItemId = 7, OrderId = 4, ProductId = 1, Quantity = 4 },
            new OrderItem() { OrderItemId = 8, OrderId = 5, ProductId = 1, Quantity = 2 }
        };

        public static readonly Supply[] Supplies = new Supply[]
        {
            new Supply() { SupplyId = 1, RestaurantId = 1, MaterialId = 1, Quantity = 1},
            new Supply() { SupplyId = 2, RestaurantId = 3, MaterialId = 1, Quantity = 6},
            new Supply() { SupplyId = 3, RestaurantId = 3, MaterialId = 1, Quantity = 3},
            new Supply() { SupplyId = 4, RestaurantId = 4, MaterialId = 1, Quantity = 2},
            new Supply() { SupplyId = 5, RestaurantId = 4, MaterialId = 1, Quantity = 3},
        };
    }
}
