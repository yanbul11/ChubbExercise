﻿using Exercise.Services.Dto;
using System.Collections.Generic;

namespace Exercise.Services
{
    public interface IRestaurantService
    {
        SupplyDto GetSupply(int restaurantId, int materialId);
    }
}
