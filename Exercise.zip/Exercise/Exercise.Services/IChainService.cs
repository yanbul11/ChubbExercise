﻿using Exercise.Services.Dto;
using System.Collections.Generic;

namespace Exercise.Services
{
    public interface IChainService
    {
        IEnumerable<DemandDto> GetDemands(int productId);
    }
}
