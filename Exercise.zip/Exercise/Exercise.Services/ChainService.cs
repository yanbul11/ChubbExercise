﻿using Exercise.Data;
using Exercise.Services.Dto;
using System.Collections.Generic;
using System.Linq;

namespace Exercise.Services
{
    public class ChainService : IChainService
    {
        private readonly ChainDbContext _chainDbContext;

        public ChainService(ChainDbContext chainDbContext)
        {
            _chainDbContext = chainDbContext;
        }

        public IEnumerable<DemandDto> GetDemands(int productId)
        {
            var demands = from order in _chainDbContext.Orders
                          join orderItem in _chainDbContext.OrderItems on order.OrderId equals orderItem.OrderId
                          where orderItem.ProductId == productId
                          group orderItem by order.RestaurantId into g
                          select new DemandDto() { RestaurantId = g.Key, Quantity = g.Sum(o => o.Quantity) };

            return demands.ToArray();
        }
    }
}
