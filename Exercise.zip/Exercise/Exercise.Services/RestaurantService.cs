﻿using Exercise.Data;
using Exercise.Data.Models;
using Exercise.Services.Dto;
using System.Collections.Generic;
using System.Linq;

namespace Exercise.Services
{
    public class RestaurantService : IRestaurantService
    {
        private readonly ChainDbContext _chainDbContext;

        public RestaurantService(ChainDbContext chainDbContext)
        {
            _chainDbContext = chainDbContext;
        }

        public SupplyDto GetSupply(int restaurantId, int materialId)
        {
            var totalQuantity = 
                _chainDbContext.Supplies.Where(o => 
                    o.RestaurantId == restaurantId && o.MaterialId == materialId)
                .Sum(o => o.Quantity);

            return new SupplyDto { Quantity = totalQuantity };
        }
    }
}
