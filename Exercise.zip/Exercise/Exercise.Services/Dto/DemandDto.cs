﻿namespace Exercise.Services.Dto
{
    public class DemandDto
    {
        public int RestaurantId { get; set; }

        public int Quantity { get; set; }
    }
}
