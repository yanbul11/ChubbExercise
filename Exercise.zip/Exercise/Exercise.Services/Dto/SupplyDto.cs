﻿namespace Exercise.Services.Dto
{
    public class SupplyDto
    {
        public int Quantity { get; set; }
    }
}
